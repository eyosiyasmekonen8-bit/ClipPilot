# ClipPilot
A free-first mobile web app starter. Upload all files inside this folder to the root of an HTTPS static site (GitHub Pages, Netlify, etc.).

## Use
- Open the deployed site on Android Chrome.
- Import a local video you own or have permission to edit.
- Generate evenly spaced candidate segments, or set start/end times manually.
- Preview and export a selected range as WebM if the browser supports MediaRecorder video capture.

## Honest limitations
- Social URLs are recognized as references only. ClipPilot does not download or extract videos from TikTok, Instagram, Facebook, or YouTube. Use the platform's own download/export feature or a file you have rights to use.
- Auto suggestions are duration-based cuts, not AI highlight detection.
- Exports are local; public share links/cloud storage require a backend.
- Browser support for video capture/export varies; WebM is the current output format.
